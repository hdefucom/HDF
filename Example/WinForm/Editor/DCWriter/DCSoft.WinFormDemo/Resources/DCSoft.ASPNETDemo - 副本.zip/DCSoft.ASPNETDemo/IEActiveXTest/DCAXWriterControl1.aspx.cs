﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DCSoft.Writer;
using DCSoft.Writer.Dom;
using System.Drawing;
using System.IO;
using System.Text;
using DCSoft.Writer.Data;


namespace DCSoft.Writer.WebDemo
{
    public partial class DCAXWriterControl1 : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (this.IsPostBack == false)
            {//加载文档
                myWriterControl.RegisterCode = "";

                btnSave.Visible = (this.myWriterControl.ContentRenderMode == Writer.Controls.WebWriterControlRenderMode.ActiveXControl);
                //选项设置
                myWriterControl.DocumentOptions.ViewOptions.EnableEncryptView = false;

                myWriterControl.RefreshView();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
        }
        protected void btnSave0_Click(object sender, EventArgs e)
        {
        }


    }
}