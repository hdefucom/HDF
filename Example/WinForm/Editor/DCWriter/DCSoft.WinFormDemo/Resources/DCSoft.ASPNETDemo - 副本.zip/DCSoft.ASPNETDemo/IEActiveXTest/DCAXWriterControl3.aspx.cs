﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DCSoft.Writer;
using DCSoft.Writer.Dom;
using System.Drawing;
using System.IO;
using System.Text;
using DCSoft.Writer.Data;


namespace DCSoft.Writer.WebDemo
{
    public partial class DCAXWriterControl3 : System.Web.UI.Page
    {
        private string CurrentFileName
        {
            get
            {
                return this.Server.MapPath("..\\DemoFile\\三门县人民医院住院病历.xml");
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.IsPostBack == false)
            {
                myWriterControl.LoadDocument(this.CurrentFileName,"XML");
                //myWriterControl.Document.LoadFromFile(this.CurrentFileName, "XML");
            }
        }



        protected void btnSave_Click(object sender, EventArgs e)
        {
            //myWriterControl.Document.ref
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }

        

    }
}