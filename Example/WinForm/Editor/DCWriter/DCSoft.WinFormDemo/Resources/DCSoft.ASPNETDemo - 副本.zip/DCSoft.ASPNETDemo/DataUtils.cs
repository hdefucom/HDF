﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Data.OleDb;
using DCSoft.ORM;
using DCSoft.Writer.WebDemo.Model;
using DCSoft.Writer;
using DCSoft.Writer.Dom;
using DCSoft.Writer.Controls;
using DCSoft.Writer.Data;
using System.Text;

namespace DCSoft.Writer.WebDemo
{
    public class DataUtils
    {
        public static void QueryListItems(QueryListItemsEventArgs args)
        {
            try
            {
                args.Handled = true;
                string strSQL = null;
                string sourceName = args.ListSourceName;
                if (sourceName != null)
                {
                    sourceName = sourceName.ToUpper();
                }
                switch (sourceName)
                {
                    case "医保类型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0006' Order by SysDesc"; break;
                    case "药品类别": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0052' Order by SysDesc"; break;
                    case "婚姻状态": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0008' Order by SysDesc"; break;
                    case "证件类型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0009' Order by SysDesc"; break;
                    case "兵种": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0010' Order by SysDesc"; break;
                    case "住院病历状态": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0012' Order by SysDesc"; break;
                    case "医嘱类型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0013' Order by SysDesc"; break;
                    case "医嘱状态": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0014' Order by SysDesc"; break;
                    case "医嘱有效期": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0015' Order by SysDesc"; break;
                    case "出院医嘱类型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0016' Order by SysDesc"; break;
                    case "民族": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0017' Order by SysDesc"; break;
                    case "职业": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0018' Order by SysDesc"; break;
                    case "联系人关系": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0019' Order by SysDesc"; break;
                    case "血型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0020' Order by SysDesc"; break;
                    case "病情": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0021' Order by SysDesc"; break;
                    case "护理等级": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0022' Order by SysDesc"; break;
                    case "药品剂量": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0025' Order by SysDesc"; break;
                    case "医院代码": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0030' Order by SysDesc"; break;
                    case "医院名称": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0031' Order by SysDesc"; break;
                    case "开关": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='9998' Order by SysDesc"; break;
                    case "医嘱频率": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0032' Order by SysDesc"; break;
                    case "医嘱给药途径": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0033' Order by SysDesc"; break;
                    case "医嘱持续时间单位": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0034' Order by SysDesc"; break;
                    case "医嘱速度单位": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0035' Order by SysDesc"; break;
                    case "医嘱总量单位": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0036' Order by SysDesc"; break;
                    case "病程类型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0037' Order by SysDesc"; break;
                    case "药房": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0038' Order by SysDesc"; break;
                    case "检验样品": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0029' Order by SysDesc"; break;
                    case "检验样品类别": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0039' Order by SysDesc"; break;
                    case "文本模板类型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0040' Order by SysDesc"; break;
                    case "病理标本": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0041' Order by SysDesc"; break;
                    case "根据医嘱频率确定执行医嘱时间": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0042' Order by SysDesc"; break;
                    case "根据检验样本确定样本的类别": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0043' Order by SysDesc"; break;
                    case "体温单中的时间点": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0044' Order by SysDesc"; break;
                    case "出生地": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0005' Order by SysDesc"; break;
                    case "籍贯": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0004' Order by SysDesc"; break;
                    case "国籍": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0003' Order by SysDesc"; break;
                    case "性别": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0002' Order by SysDesc"; break;
                    case "收费类型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0001' Order by SysDesc"; break;
                    case "文化水平": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0007' Order by SysDesc"; break;
                    case "入院方式": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0054' Order by SysDesc"; break;
                    case "入院情况": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0055' Order by SysDesc"; break;
                    case "联系人类型": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0057' Order by SysDesc"; break;
                    case "付款方式": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0056' Order by SysDesc"; break;

                    case "DOCEX": strSQL = "Select Name , Name From EMR_Docex Order By Name"; break;
                    case "EXAMIN": strSQL = "Select Examine , Examine From EMR_Examine Order By Examine"; break;
                    case "科室": strSQL = "Select Name , id from EMR_DEPARTMENT ORDER BY name"; break;
                    case "病人来源": strSQL = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0053' Order by SysDesc"; break;
                    case "本科门诊医生": strSQL = "Select em_Name , ID from emr_employee order by em_name"; break;
                    case "本科住院医生": strSQL = "Select em_Name , ID from emr_employee order by em_name"; break;
                    case "多栏药品列表": strSQL = "Select NAME,FOREIGNNAME,SPEC,MEDECODE FROM EMR_DOCEX ORDER BY NAME"; break;
                }
                if (args.KBEntry != null && args.KBEntry.Style == KBEntryStyle.ListSQL)
                {
                    strSQL = args.KBEntry.Value;
                }
                if (string.IsNullOrEmpty(strSQL) == false)
                {
                    using (IDbConnection conn = CreateConnection())
                    {
                        conn.Open();
                        using (IDbCommand cmd = conn.CreateCommand())
                        {
                            cmd.CommandText = strSQL;
                            IDataReader reader = cmd.ExecuteReader();
                            int fieldCount = reader.FieldCount;
                            while (reader.Read())
                            {
                                ListItem item = new ListItem();
                                if (sourceName == "多栏药品列表")
                                {
                                    item.Text = Convert.ToString(reader.GetValue(0));
                                    item.Value = Convert.ToString(reader.GetValue(0));
                                    StringBuilder str = new StringBuilder();
                                    for (int iCount = 0; iCount < fieldCount; iCount++)
                                    {
                                        if (iCount > 0)
                                        {
                                            str.Append(",");
                                        }
                                        if (reader.IsDBNull(iCount) == false)
                                        {
                                            string txt = Convert.ToString(reader.GetValue(iCount));
                                            if (txt != null)
                                            {
                                                // 过滤掉文字中的逗号,因为在编辑器列表是中是用逗号来进行分组拆分的。
                                                txt = txt.Replace(',', '_');
                                                str.Append(txt);
                                            }
                                        }
                                    }
                                    item.TextInList = str.ToString();
                                    args.AddResultItem(item);
                                    continue;
                                }
                                if (reader.IsDBNull(0) == false)
                                {
                                    item.Text = Convert.ToString(reader.GetValue(0));
                                }
                                if (fieldCount == 1)
                                {
                                    item.Value = item.Text;
                                }
                                else
                                {
                                    if (reader.IsDBNull(1) == false)
                                    {
                                        item.Value = Convert.ToString(reader.GetValue(1));
                                    }
                                }
                                if (fieldCount >= 3)
                                {
                                    if (reader.IsDBNull(2) == false)
                                    {
                                        item.SpellCode = Convert.ToString(reader.GetValue(2));
                                    }
                                }
                                args.AddResultItem(item);
                            }//while
                            reader.Close();
                        }//using
                    }//using
                }//if
            }
            catch (Exception ext)
            {
                System.Diagnostics.Debug.WriteLine(ext.ToString());
            }
        }

        /// <summary>
        /// 创建数据库连接对象
        /// </summary>
        /// <returns></returns>
        public static IDbConnection CreateConnection()
        {
            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\""
                + System.Web.HttpContext.Current.Server.MapPath("~\\App_Data\\EMR.mdb") + "\"";
            return conn;
        }

        /// <summary>
        /// 填充病人列表控件
        /// </summary>
        /// <param name="list">列表控件</param>
        /// <param name="specifySection">指定的科室</param>
        public static void FillPatientList(System.Web.UI.WebControls.DropDownList list, string specifySection)
        {
            using (IDbConnection conn = CreateConnection())
            {
                conn.Open();
                using (IDbCommand cmd = conn.CreateCommand())
                {
                    string sql = "Select pa_id , pa_name From EMR_Patients ";
                    if (string.IsNullOrEmpty(specifySection) == false)
                    {
                        sql = sql + " Where PA_PIH_PATIENT_SPACE ='" + specifySection + "'";
                    }
                    sql = sql + " Order by pa_name";
                    cmd.CommandText = sql;
                    IDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        System.Web.UI.WebControls.ListItem item = new System.Web.UI.WebControls.ListItem();
                        item.Text = Convert.ToString(reader.GetValue(1));
                        item.Value = Convert.ToString(reader.GetValue(0));
                        list.Items.Add(item);
                    }//while
                    reader.Close();
                }
            }
        }

        private static ORMEngine _ORMEngine = null;
        public static ORMEngine GetORMEngine()
        {
            if (_ORMEngine == null)
            {
                _ORMEngine = new ORMEngine();
                _ORMEngine.AddType(typeof(Model.EMR_Patients));
                _ORMEngine.DataBase.Connection = CreateConnection();
            }
            return _ORMEngine;
        }
        //public int UpdateEntryInstance(object instance)
        //{
        //    if (instance is EMR_Patients)
        //    {
        //        using (ORMEngine engine = CreateORMEngine())
        //        {
        //            return engine.Update(instance);
        //        }
        //    }
        //    return 0;
        //}
    }
}