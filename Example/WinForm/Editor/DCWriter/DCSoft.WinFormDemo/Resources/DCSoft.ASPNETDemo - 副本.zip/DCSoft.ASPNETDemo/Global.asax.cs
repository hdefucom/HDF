﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Xml;
using System.IO;
using System.Data;

namespace DCSoft.Writer.WebDemo
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            DCSoft.Writer.Controls.WebWriterControl.StaticSetRegisterCode("");
            DCSoft.TemperatureChart.WebTemperatureControl.StaticSetRegisterCode("");

            
        }

        protected void Session_Start(object sender, EventArgs e)
        {

            System.Web.HttpRequest request = System.Web.HttpContext.Current.Request;
            string agent= request.UserAgent;
            if (agent != null)
            {
                if (agent.IndexOf("bingbot") > 0 || agent.IndexOf("Googlebot") > 0 || agent.IndexOf("MJ12bot") > 0)
                {
                    // 搜索引擎
                    return;
                }
            }
            string logFileName = System.Web.HttpContext.Current.Server.MapPath("\\weblog.txt");
            try
            {
                lock (typeof(Global))
                {
                    using (System.IO.StreamWriter writer = new System.IO.StreamWriter(logFileName, true, System.Text.Encoding.Default))
                    {
                        writer.WriteLine(
                            DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "|IP:" + request.UserHostAddress + "; Agent:\"" + request.UserAgent + "\"; URL:\"" + request.Url + "\"; Refer:\"" + request.UrlReferrer + "\"");
                    }//using
                }
            }
            catch (Exception ext)
            {
            }
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            HttpContext.Current.Response.Cache.SetNoStore();  
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {
           
        }

        protected void Application_End(object sender, EventArgs e)
        {
            

        }
    }
}