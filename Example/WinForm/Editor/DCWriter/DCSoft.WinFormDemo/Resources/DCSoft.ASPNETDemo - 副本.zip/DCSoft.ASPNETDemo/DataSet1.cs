﻿namespace DCSoft.Writer.WebDemo {
    
    
    public partial class DataSet1 {
    }
}
