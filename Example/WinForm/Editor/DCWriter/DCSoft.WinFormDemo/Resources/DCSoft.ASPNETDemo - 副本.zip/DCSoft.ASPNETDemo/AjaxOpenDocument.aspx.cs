﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DCSoft.Writer;
using DCSoft.Writer.Dom;
using System.Drawing;
using System.IO;
using System.Text;
using DCSoft.Writer.Controls;
//using DCSoft.Writer.Serialization.Html;


namespace DCSoft.Writer.WebDemo
{
    public partial class AjaxOpenDocument : System.Web.UI.Page
    {
         
        private string CurrentFileName
        {
            get
            {
                string txt = lstFile.SelectedValue;
                if (string.IsNullOrEmpty(txt) == false)
                {
                    return System.IO.Path.Combine( OnlineWriterPC.CurrentDir , txt);
                }
                return null;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            //DCSoft.Writer.Controls.WebWriterControl.SaveRequestHtmlForDebug = true ;
            //DCSoft.Writer.Controls.WebWriterControl.DebugFileNameSavedRequestHtml = @"D:\金山快盘\项目文件\江苏张家港奥洋医院\RequestHtml_2015-12-11 16_23_32.html";
            if (lstFile.Items.Count == 0)
            {
                List<string> fileNames = new List<string>( System.IO.Directory.GetFiles( OnlineWriterPC.CurrentDir, "*.xml"));
                fileNames.Sort();
                foreach (string fileName in fileNames  )
                {
                    lstFile.Items.Add(new ListItem(System.IO.Path.GetFileName(fileName), fileName));
                }
                if (lstFile.Items.Count > 0)
                {
                    lstFile.SelectedIndex = 0;
                }
                
            }
            SetControlOptions();
            if (this.IsPostBack == false)
            {
                myWriterControl.LoadDocument(
                    this.CurrentFileName,
                    null);
                myWriterControl.Document.FileName = this.CurrentFileName ;
                myWriterControl.ControlOptions.FormView = Writer.Controls.FormViewMode.Strict;
                myWriterControl.DocumentOptions.ViewOptions.ShowParagraphFlag = false;
                myWriterControl.DocumentOptions.ViewOptions.ShowInputFieldStateTag = true;
                myWriterControl.DocumentOptions.ViewOptions.EnableEncryptView = true;
                //myWriterControl.ContentRenderMode = WebWriterControlRenderMode.ActiveXControl   ;
                myWriterControl.BackgroundTextOutputMode = DCBackgroundTextOutputMode.Underline;
            }
            // 绑定事件
            myWriterControl.EventQueryListItems = new QueryListItemsEventHandler(My_QueryListItems);
            myWriterControl.EventSaveFileContent = new WriterSaveFileContentEventHandler(My_SaveFileContent);
            myWriterControl.EventSaveSelectionContent = new WriterSaveFileContentEventHandler(My_SaveSelectionContent);
            myWriterControl.EventReadFileContent = new WriterReadFileContentEventHandler( this.My_ReadFileContent );
            
        }


        private void SetControlOptions()
        {
            myWriterControl.ExcludeKeywords = "月经,子宫,卵巢";
            myWriterControl.DocumentOptions.ViewOptions.ShowInputFieldStateTag = true;
            myWriterControl.DocumentOptions.ViewOptions.FieldInvalidateValueBackColor = Color.LightPink;
            // 用Tab键在各个输入域之间切换
            myWriterControl.DocumentOptions.BehaviorOptions.MoveFocusHotKey = MoveFocusHotKeys.Tab;
            //myWriterControl.AutoLine = chkAutoLine.Checked;
            //if (chkFormView.Checked)
            //{
            //    myWriterControl.FormView = Writer.Controls.FormViewMode.Strict;
            //}
            //else
            //{
            //    myWriterControl.FormView = Writer.Controls.FormViewMode.Disable;
            //}
        }

        /// <summary>
        /// 处理客户端AJAX脚本引发的查询下拉列表项目事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void My_QueryListItems(object sender, QueryListItemsEventArgs args)
        {
            DataUtils.QueryListItems(args);
        }

        /// <summary>
        /// 处理客户端AJAX脚本引发的加载文件事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void My_ReadFileContent(object sender, WriterReadFileContentEventArgs args)
        {
            if (System.IO.File.Exists(args.FileName))
            {
                byte[] bs = System.IO.File.ReadAllBytes(args.FileName);
                args.ResultBinary = bs;
                args.Handled = true;
            }
        }

        /// <summary>
        /// 处理客户端AJAX脚本引发的保存文件事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void My_SaveSelectionContent(object sender, WriterSaveFileContentEventArgs args)
        {
            string fileName = args.UserParameter ;
            if( string.IsNullOrEmpty( fileName ) )
            {
                args.Result = false;
            }
            fileName = Path.Combine( OnlineWriterPC.CurrentDir, Path.GetFileName(fileName + ".xml"));
            args.Document.Save(fileName, null);
            args.FileName = fileName;
            args.Result = true;
        }

        /// <summary>
        /// 处理客户端AJAX脚本引发的保存文件事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void My_SaveFileContent(object sender, WriterSaveFileContentEventArgs args)
        {
            string fileName = args.Document.FileName;
            if (string.IsNullOrEmpty(fileName))
            {
                fileName = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ".xml";
            }
            fileName = Path.Combine( OnlineWriterPC.CurrentDir, Path.GetFileName(fileName));
            args.Document.Save(fileName, null);
            args.FileName = fileName;
            args.Result = true;
        }
       
        protected void btnSave_Click(object sender, EventArgs e)
        {
            // 保存文件
             string fileName = myWriterControl.Document.FileName;
            if (string.IsNullOrEmpty(fileName))
            {
                fileName = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ".xml";
            }
            fileName = Path.Combine(OnlineWriterPC.CurrentDir, Path.GetFileName(fileName));
            myWriterControl.SaveDocument( fileName , null );
        }
         
         

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (this.myWriterControl.ContentRenderMode == WebWriterControlRenderMode.NormalHtmlEditable)
            {
                this.myWriterControl.ContentRenderMode = WebWriterControlRenderMode.PagePreviewHtml;
            }
            else
            {
                this.myWriterControl.ContentRenderMode = WebWriterControlRenderMode.NormalHtmlEditable;
            }
        }
         
    }
}