﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Xml;
using System.IO;
using System.Data;

namespace DCSoft.ASPNETDemo
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            //DCSoft.Writer.Controls.WebWriterControl.StaticSetRegisterCode("03508C034000000000003E000000E58D97E4BAACE983BDE6988CE4BFA1E681AFE7A791E68A80E69C89E99990E585ACE58FB832303136E5B9B4E5BAA6E6B58BE8AF95E78988E68E88E69D8332CA340000021A3E000000E58D97E4BAACE983BDE6988CE4BFA1E681AFE7A791E68A80E69C89E99990E585ACE58FB832303136E5B9B4E5BAA6E6B58BE8AF95E78988E68E88E69D8332010000001C0089B0A06E");
            //DCSoft.TemperatureChart.WebTemperatureControl.StaticSetRegisterCode("02C52605000137000000E58D97E4BAACE983BDE6988CE4BFA1E681AFE7A791E68A80E69C89E99990E585ACE58FB832303136E5B9B4E5BAA6E6B58BE8AF95E78988C93400009C4A37000000E58D97E4BAACE983BDE6988CE4BFA1E681AFE7A791E68A80E69C89E99990E585ACE58FB832303136E5B9B4E5BAA6E6B58BE8AF95E789880F0000001C000124E37F");

            DCSoft.Writer.Controls.WebWriterControl.StaticSetRegisterCode("03C98C034804000000003D000000E58D97E4BAACE983BDE6988CE4BFA1E681AFE7A791E68A80E69C89E99990E585ACE58FB832303137E5B9B4E5BAA6E6B58BE8AF95E78988E68E88E69D8337360000AC7C3D000000E58D97E4BAACE983BDE6988CE4BFA1E681AFE7A791E68A80E69C89E99990E585ACE58FB832303137E5B9B4E5BAA6E6B58BE8AF95E78988E68E88E69D830F0000003C00D1679ABB");
            DCSoft.TemperatureChart.WebTemperatureControl.StaticSetRegisterCode("03C98C034804000000003D000000E58D97E4BAACE983BDE6988CE4BFA1E681AFE7A791E68A80E69C89E99990E585ACE58FB832303137E5B9B4E5BAA6E6B58BE8AF95E78988E68E88E69D8337360000AC7C3D000000E58D97E4BAACE983BDE6988CE4BFA1E681AFE7A791E68A80E69C89E99990E585ACE58FB832303137E5B9B4E5BAA6E6B58BE8AF95E78988E68E88E69D830F0000003C00D1679ABB");
        }

        protected void Session_Start(object sender, EventArgs e)
        {

            System.Web.HttpRequest request = System.Web.HttpContext.Current.Request;
            string agent= request.UserAgent;
            if (agent != null)
            {
                if (agent.IndexOf("bingbot") > 0 || agent.IndexOf("Googlebot") > 0 || agent.IndexOf("MJ12bot") > 0)
                {
                    // 搜索引擎
                    return;
                }
            }
            try
            {
                string logFileName = System.Web.HttpContext.Current.Server.MapPath("\\weblog.txt");
                lock (typeof(Global))
                {
                    using (System.IO.StreamWriter writer = new System.IO.StreamWriter(logFileName, true, System.Text.Encoding.Default))
                    {
                        writer.WriteLine(
                            DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "|IP:" + request.UserHostAddress + "; Agent:\"" + request.UserAgent + "\"; URL:\"" + request.Url + "\"; Refer:\"" + request.UrlReferrer + "\"");
                    }//using
                }
            }
            catch (Exception ext)
            {
            }
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            HttpContext.Current.Response.Cache.SetNoStore();  
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {
           
        }

        protected void Application_End(object sender, EventArgs e)
        {
            

        }
    }
}