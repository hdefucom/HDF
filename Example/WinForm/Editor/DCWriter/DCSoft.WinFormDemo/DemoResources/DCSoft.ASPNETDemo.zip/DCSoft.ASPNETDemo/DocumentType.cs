﻿using System;
using System.Collections.Generic;
using System.Web;

namespace DCSoft.ASPNETDemo
{
    /// <summary>
    /// 文档内容
    /// </summary>
    public enum DocumentType
    {
        /// <summary>
        /// 病案首页
        /// </summary>
        Home,
        /// <summary>
        /// 首次病程记录
        /// </summary>
        FirstCourseRecord,
        /// <summary>
        /// 病程记录
        /// </summary>
        CourseRecord,
        /// <summary>
        /// 手术记录
        /// </summary>
        OperationRecord
    }
}