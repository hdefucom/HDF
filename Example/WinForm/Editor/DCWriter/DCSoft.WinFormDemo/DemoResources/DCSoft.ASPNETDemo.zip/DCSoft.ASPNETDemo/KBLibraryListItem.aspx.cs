﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data ;
using System.Xml;

namespace DCSoft.ASPNETDemo
{
    /// <summary>
    /// 知识库列表页面
    /// </summary>
    /// <remarks>编制 袁永福</remarks>
    public partial class KBLibraryListItem : System.Web.UI.Page
    {
        private static Dictionary<string, string> _ListSourceSQLs = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (_ListSourceSQLs == null)
            {
                _ListSourceSQLs = new Dictionary<string, string>();
                _ListSourceSQLs["医保类型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0006' Order by SysDesc";
                _ListSourceSQLs["药品类别"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0052' Order by SysDesc";
                _ListSourceSQLs["婚姻状态"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0008' Order by SysDesc";
                _ListSourceSQLs["证件类型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0009' Order by SysDesc";
                _ListSourceSQLs["兵种"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0010' Order by SysDesc";
                _ListSourceSQLs["住院病历状态"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0012' Order by SysDesc";
                _ListSourceSQLs["医嘱类型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0013' Order by SysDesc";
                _ListSourceSQLs["医嘱状态"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0014' Order by SysDesc";
                _ListSourceSQLs["医嘱有效期"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0015' Order by SysDesc";
                _ListSourceSQLs["出院医嘱类型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0016' Order by SysDesc";
                _ListSourceSQLs["民族"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0017' Order by SysDesc";
                _ListSourceSQLs["职业"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0018' Order by SysDesc";
                _ListSourceSQLs["联系人关系"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0019' Order by SysDesc";
                _ListSourceSQLs["血型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0020' Order by SysDesc";
                _ListSourceSQLs["病情"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0021' Order by SysDesc";
                _ListSourceSQLs["护理等级"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0022' Order by SysDesc";
                _ListSourceSQLs["药品剂量"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0025' Order by SysDesc";
                _ListSourceSQLs["医院代码"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0030' Order by SysDesc";
                _ListSourceSQLs["医院名称"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0031' Order by SysDesc";
                _ListSourceSQLs["开关"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='9998' Order by SysDesc";
                _ListSourceSQLs["医嘱频率"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0032' Order by SysDesc";
                _ListSourceSQLs["医嘱给药途径"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0033' Order by SysDesc";
                _ListSourceSQLs["医嘱持续时间单位"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0034' Order by SysDesc";
                _ListSourceSQLs["医嘱速度单位"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0035' Order by SysDesc";
                _ListSourceSQLs["医嘱总量单位"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0036' Order by SysDesc";
                _ListSourceSQLs["病程类型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0037' Order by SysDesc";
                _ListSourceSQLs["药房"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0038' Order by SysDesc";
                _ListSourceSQLs["检验样品"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0029' Order by SysDesc";
                _ListSourceSQLs["检验样品类别"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0039' Order by SysDesc";
                _ListSourceSQLs["文本模板类型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0040' Order by SysDesc";
                _ListSourceSQLs["病理标本"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0041' Order by SysDesc";
                _ListSourceSQLs["根据医嘱频率确定执行医嘱时间"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0042' Order by SysDesc";
                _ListSourceSQLs["根据检验样本确定样本的类别"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0043' Order by SysDesc";
                _ListSourceSQLs["体温单中的时间点"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0044' Order by SysDesc";
                _ListSourceSQLs["出生地"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0005' Order by SysDesc";
                _ListSourceSQLs["籍贯"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0004' Order by SysDesc";
                _ListSourceSQLs["国籍"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0003' Order by SysDesc";
                _ListSourceSQLs["性别"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0002' Order by SysDesc";
                _ListSourceSQLs["收费类型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0001' Order by SysDesc";
                _ListSourceSQLs["文化水平"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0007' Order by SysDesc";
                _ListSourceSQLs["入院方式"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0054' Order by SysDesc";
                _ListSourceSQLs["入院情况"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0055' Order by SysDesc";
                _ListSourceSQLs["联系人类型"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0057' Order by SysDesc";
                _ListSourceSQLs["付款方式"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0056' Order by SysDesc";

                _ListSourceSQLs["DOCEX"] = "Select Name , Name From EMR_Docex Order By Name";
                _ListSourceSQLs["EXAMIN"] = "Select Examine , Examine From EMR_Examine Order By Examine";
                _ListSourceSQLs["科室"] = "Select Name , id from EMR_DEPARTMENT where id not in(select distinct(substr(id,0,2)) from emr_department WHERE grade like '1') AND ID NOT LIKE '00'and (DEPT_STATE='0' AND BELONG_TYPE LIKE '%1') ORDER BY ID";
                _ListSourceSQLs["病人来源"] = "Select SysDesc , SysCode From EMR_SysCode Where SysType='0053' Order by SysDesc";
                _ListSourceSQLs["本科门诊医生"] = "Select em_Name , ID from emr_employee order by em_name";
                _ListSourceSQLs["本科住院医生"] = "Select em_Name , ID from emr_employee order by em_name";
            }
            string name = this.Request.QueryString["name"];
            if (name == null)
            {
                name = "";
            }
            name = name.Trim();
            this.Response.ContentType = "xml/text";
            System.Xml.XmlTextWriter writer = new XmlTextWriter(this.Response.Output);
            writer.WriteStartDocument();
            writer.WriteStartElement("ListItems");
            writer.WriteAttributeString("Name", name);

            foreach (string key in _ListSourceSQLs.Keys)
            {
                if (string.Compare(key, name, true) == 0)
                {
                    string sql = _ListSourceSQLs[key];
                    using (IDbConnection conn = DataUtils.CreateConnection())
                    {
                        conn.Open();
                        using (IDbCommand cmd = conn.CreateCommand())
                        {
                            cmd.CommandText = sql;
                            IDataReader reader = cmd.ExecuteReader();
                            while (reader.Read())
                            {
                                writer.WriteStartElement("Item");
                                writer.WriteStartElement("Text");
                                if (reader.IsDBNull(0) == false)
                                {
                                    writer.WriteString(Convert.ToString(reader.GetValue(0)));
                                }
                                writer.WriteEndElement();
                                writer.WriteStartElement("Value");
                                if (reader.IsDBNull(1) == false)
                                {
                                    writer.WriteString(Convert.ToString(reader.GetValue(1)));
                                }
                                writer.WriteEndElement();
                                writer.WriteEndElement();
                            }//while
                            reader.Close();
                        }//using
                    }//using
                }//if
            }// using
            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
        }
    }
}