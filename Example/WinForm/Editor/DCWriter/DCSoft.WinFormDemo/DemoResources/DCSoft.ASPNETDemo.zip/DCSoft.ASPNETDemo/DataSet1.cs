﻿namespace DCSoft.ASPNETDemo {
    
    
    public partial class DataSet1 {
    }
}
