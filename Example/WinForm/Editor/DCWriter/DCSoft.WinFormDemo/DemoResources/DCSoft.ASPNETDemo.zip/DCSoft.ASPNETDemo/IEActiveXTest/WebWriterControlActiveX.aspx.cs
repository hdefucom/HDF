﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DCSoft.Writer.WebDemo.IEActiveXTest
{
    public partial class WebWriterControlActiveX : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string fileName = this.Server.MapPath("demo4.xml");
            //this.WebWriterControl1.LoadDocument(fileName, null);
        }

        protected void btnOpen_Click(object sender, EventArgs e)
        {
            string fileName = this.Server.MapPath("demo4.xml");
            this.WebWriterControl1.LoadDocument( fileName , null);
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            this.WebWriterControl1.SaveDocument(this.Server.MapPath("dmoe_save.xml"), null);
        }

        protected void btnLoadTemp_Click(object sender, EventArgs e)
        {
            this.WebWriterControl1.LoadDocument(this.Server.MapPath("dmoe_save.xml"), null);
        }
    }
}