﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using DCSoft.Writer.Dom;

namespace DCSoft.ASPNETDemo
{
    public partial class DCAXWriterControl2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string template = this.Request.QueryString["template"];
            string sessionName = this.Request.QueryString["session"];
            txtTemplate.Text = "Template/" + template;
            txtParameterName.Text = sessionName;
            if (this.IsPostBack == false)
            {
                // 设置XML格式的参数值
                object obj = this.Session[sessionName];
                if (obj != null)
                {
                    //string xml = Util.EntryToXml(sessionName, obj);
                    //txtXMLParameter.Text = xml;
                    //using (System.IO.StreamWriter writer = new StreamWriter( this.Server.MapPath("data.xml") ,false , Encoding.Unicode   ))
                    //{
                    //    writer.Write(xml);
                    //}
                }
            }
        }

        /// <summary>
        /// 保存按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
         
        }
    }
}