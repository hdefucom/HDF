﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace DCSoft.ASPNETDemo
{
    /// <summary>
    /// 获得模板内容的页面
    /// </summary>
    public partial class KBLibraryTemplate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string name = this.Request.QueryString["name"];
            this.Response.ContentType = "xml/text";
            this.Response.ContentEncoding = System.Text.Encoding.UTF8;
            using (IDbConnection conn = DataUtils.CreateConnection())
            {
                conn.Open();
                using (IDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "Select ObjectData From ET_Document where ObjectID ='" + name + "'";
                    IDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        if (reader.IsDBNull(0) == false)
                        {
                            this.Response.Write(Convert.ToString(reader.GetValue(0)));
                        }
                    }
                    reader.Close();
                }//using
            }//using
        }
    }
}